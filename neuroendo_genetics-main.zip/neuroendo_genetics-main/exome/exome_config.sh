script_loc="Hannah/scripts"

###################
###MAJOR VOLUMES###
###################

pheno_file="phenos_complete_vols_exome_0923_all.phe"
pheno_input="Hannah/phenotypes/phenos_complete_vols_exome_0923_all.phe"
output_location="Hannah/results_v7"
type="all"
